package com.example.whowantstobeamillionaire;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.widget.TextView;

public class Lost extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_lost);

        TextView lost = (TextView) findViewById(R.id.tvLostMsg); // Find lost by id
        Intent intent = new Intent(this, MainActivity.class); // Create new intent to move to the MainActivity
        // screen if the user wants to play the game again.
        startActivity(intent); // Start the intent
    }
}