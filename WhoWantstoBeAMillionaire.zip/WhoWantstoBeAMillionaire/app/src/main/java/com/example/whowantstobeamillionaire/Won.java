package com.example.whowantstobeamillionaire;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.widget.TextView;

public class Won extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_won);

        TextView won = (TextView) findViewById(R.id.tvWonMsg); // Find won by id

        Intent intent = new Intent(this, MainActivity.class); // Create new intent to move to the MainActivity
        // screen if the user wants to play the game again.
        startActivity(intent); // Start the intent
    }
}