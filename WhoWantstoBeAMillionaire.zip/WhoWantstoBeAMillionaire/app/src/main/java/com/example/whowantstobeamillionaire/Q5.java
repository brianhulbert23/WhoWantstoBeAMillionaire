package com.example.whowantstobeamillionaire;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.RadioButton;
import android.widget.Toast;

public class Q5 extends AppCompatActivity {
    int newScore; // Initialize newScore as an int
    int currentScore = 1000; // Initialize currentScore as 1000 so the fourth question starts off with $1000 if the fourth question is correct.


    public void correctAnswer() { // Create correctAnswer method
        int newScore = currentScore + 4000; // Add currentScore to 4000 since the
        // fourth question will be worth $1000 if the answer to the question is correct.
        Intent intent = new Intent(this, Q6.class); // Create intent to move to the Q6 screen.
        startActivity(intent); // Start intent
    }

    public void wrongAnswer() { // Create wrongAnswer method
        Intent intent = new Intent(this, Lost.class); // Create intent to move to the Lost screen.
        startActivity(intent); // Start intent
    }
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_q5);

        Button choice1 = (RadioButton) findViewById(R.id.rbChoice1);
        Button choice2 = (RadioButton) findViewById(R.id.rbChoice2);
        Button choice3 = (RadioButton) findViewById(R.id.rbChoice3);
        Button choice4 = (RadioButton) findViewById(R.id.rbChoice4);

       choice1.setOnClickListener(new View.OnClickListener() { // Create onClickListener method
        @Override
        public void onClick(View view) { // Create onClick method
            Toast.makeText(getApplicationContext(), "Wrong", Toast.LENGTH_SHORT).show(); // Display Wrong in toast
            wrongAnswer(); // Call wrongAnswer() method
        }

    });

        choice2.setOnClickListener(new View.OnClickListener() { // Create onClickListener method
            @Override
            public void onClick(View view) { // Create onClick method
                Toast.makeText(getApplicationContext(), "Correct, your score is $" + newScore, Toast.LENGTH_SHORT).show(); // Display Correct and your score in toast
                correctAnswer(); // Call correctAnswer method
            }
        });

        choice3.setOnClickListener(new View.OnClickListener() { // Create onClickListener method
            @Override
            public void onClick(View view) { // Create onClick method
                Toast.makeText(getApplicationContext(), "Wrong", Toast.LENGTH_SHORT).show(); // Display Wrong in toast
                wrongAnswer(); // Call wrongAnswer() method
            }
        });

        choice4.setOnClickListener(new View.OnClickListener() { // Create onClickListener method
            @Override
            public void onClick(View view) { // Create onClick method
                Toast.makeText(getApplicationContext(), "Wrong", Toast.LENGTH_SHORT).show(); // Display Wrong in toast
                wrongAnswer(); // Call wrongAnswer() method
            }
        });

}

}