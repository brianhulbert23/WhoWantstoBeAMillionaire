package com.example.whowantstobeamillionaire;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.RadioButton;
import android.widget.Toast;

public class Q4 extends AppCompatActivity {

    int newScore; // Initialize newScore as an int
    int currentScore = 700; // Initialize currentScore as 700 so the third question starts off with $700 if the third question is correct.

    public void correctAnswer() { // Create correctAnswer method
        int newScore = currentScore + 1000; // Add currentScore to 1000 since the
        // third question will be worth $700 if the answer to the question is correct.
        Intent intent = new Intent(this, Q5.class); // Create new intent to moves to the Q5 screen.
        startActivity(intent); // Start intent
    }

    public void wrongAnswer() { // Create wrongAnswer method
        Intent intent = new Intent(this, Lost.class); // Create new intent to move to the Lost screen.
        startActivity(intent); // Start intent
    }
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_q4);

        Button choice1 = (RadioButton) findViewById(R.id.rbChoice1);
        Button choice2 = (RadioButton) findViewById(R.id.rbChoice2);
        Button choice3 = (RadioButton) findViewById(R.id.rbChoice3);
        Button choice4 = (RadioButton) findViewById(R.id.rbChoice4);

        choice1.setOnClickListener(new View.OnClickListener() { // Create onClickListener method
        @Override
        public void onClick(View view) { // Create onClick method
            Toast.makeText(getApplicationContext(), "Wrong", Toast.LENGTH_SHORT).show(); // Display Wrong in toast
            wrongAnswer(); // Call wrongAnswer() method
        }

    });

        choice2.setOnClickListener(new View.OnClickListener() { // Create onClickListener method
            @Override
            public void onClick(View view) { // Create onClick method
                Toast.makeText(getApplicationContext(), "Wrong" + newScore, Toast.LENGTH_SHORT).show(); // Display Wrong in toast
                wrongAnswer(); // Call wrongAnswer() method
            }
        });

        choice3.setOnClickListener(new View.OnClickListener() { // Create onClickListener method
            @Override
            public void onClick(View view) { // Create onClick method
                Toast.makeText(getApplicationContext(), "Wrong", Toast.LENGTH_SHORT).show(); // Display Wrong in toast
                wrongAnswer(); // Call wrongAnswer() method
            }
        });

        choice4.setOnClickListener(new View.OnClickListener() { // Create onClickListener method
            @Override
            public void onClick(View view) { // Create onClick method
                Toast.makeText(getApplicationContext(), "Correct, your score is $" + newScore, Toast.LENGTH_SHORT).show(); // Display Correct and your score in toast
                correctAnswer(); // Call correctAnswer() method
            }
        });

}

}