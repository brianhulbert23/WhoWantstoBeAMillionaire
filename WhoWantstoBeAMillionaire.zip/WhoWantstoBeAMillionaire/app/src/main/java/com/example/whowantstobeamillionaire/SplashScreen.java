package com.example.whowantstobeamillionaire;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;

import android.os.Handler;

public class SplashScreen extends AppCompatActivity {
public void start() { // start method created for intent to MainActivity after the splash screen.
    Intent intent = new Intent(this, MainActivity.class); // Create new intent to move to the MainActivity.
}
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_splash_screen);

        Handler handler = new Handler(); // Create new handler
        handler.postDelayed(new Runnable() { // Delay handler
            public void run() { // Create run method to run the start method.

                start(); // Call method
            }
        }, 3000); // Specify the number of seconds the splash screen is shown for.
        
    }
}
