package com.example.whowantstobeamillionaire;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class MainActivity extends AppCompatActivity {
    Button playButton;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Button playButton = findViewById(R.id.btnPlay); // Find playButton by id.
        Intent intent = new Intent(this, Q1.class); // Create intent to move to Q1 screen.

        playButton.setOnClickListener(new View.OnClickListener() { // Create onClickListener method
            @Override
            public void onClick(View view) { // Create onClick method
                startActivity(intent); // Start intent
            }
        });
    }
}
